﻿#白细胞团队军火武器之追风箭
<h1 id="cpasword-is-about-weak-password-create-tools"><a name="cpasword-is-about-weak-password-create-tools" href="#cpasword-is-about-weak-password-create-tools"></a>Cpasword is about weak password create tools</h1>
<p class="toc" style="undefined"></p><p>1.Cpassword imput/username.txt is you enter your want to create weak password username in the username.txt<br>2.run the Cpassword.py<br>3.see the log/info.log, if have someone username in the info.log ,that mean have username can’t create ,and you can enter the example :zhanglili-张丽丽,if info.txt no something. that meaning you create dict success<br>4.you can see output/userdict.txt</p>
<p>qq:<ins>959297822</ins><br>email:pyphrb@163.com</p>

